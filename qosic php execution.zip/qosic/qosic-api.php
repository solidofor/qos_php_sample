<?php
require 'vendor/autoload.php';

// Initialize Guzzle client
$client = new \GuzzleHttp\Client();
$credentials = base64_encode("$username:$password");
$server_link = 'http://ip_address';
// Create a POST request
$res = $client->request('POST', "$server_link/QosicBridge/user/requestpayment", array(
						'base_uri' => $server_link,
						'headers' => [
										'Accept' => 'application/json',
										'Content-type' => 'application/json',
										'Authorization' => 'Basic '.$credentials,
									 ],
						'json' => [	
									"msisdn"    => "2291323990",
									"amount"    => "200",
									"firstname" => "David",
									"lastname"  => "Mark",
									"transref"  => "12345",
									"clientid"  => "user_id"
								  ],
						'verify' => false,
						'exceptions' => false
						//'form_params' => array('key1' => 'value1', 'key2' => 'value2')
						));
																		
// Getting the response object, e.g. read the headers, body, etc.
 echo $res->getStatusCode();   // e.g. 200
 echo '<br/>';
 echo $res->getHeaderLine('content-type');  // e.g. 'application/json; charset=utf8'
 echo '<br/>';
 echo $res->getBody(); // e.g. '{"id": 1420053, "name": "guzzle", ...}'
 echo '<br/><br/>';

//Parsing the response array, e.g. array('key1' => 'value1', 'key2' => 'value2')
$response = json_decode($res->getBody(), true); 

echo 'Response Code: '.$response['responsecode']; //This is the response code for the transaction i.e 00
echo '<br/>';
echo 'Response Msg: '.$response['responsemsg']; //This describes the response message
echo '<br/>';
echo 'Transref: '.$response['transref']; //This is the transref sent in the request message
echo '<br/>';
echo 'Comment: '.$response['comment']; //This is a comment
echo '<br/>';